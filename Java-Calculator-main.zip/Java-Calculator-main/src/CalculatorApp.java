import gui.CalculatorGui;

public class CalculatorApp {
    public static void main(String[] args){
        new CalculatorGui().setVisible(true);
    }
}
